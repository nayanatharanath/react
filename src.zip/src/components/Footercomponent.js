import React from 'react'

const Footercomponent = () => {
  return (
    <div>
       <footer className = "footer">
                 <span className="text-muted">All Rights Reserved 2023 @E-Learning Platform</span>
            </footer>
    </div>
  )
}

export default Footercomponent
