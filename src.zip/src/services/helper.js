// import axios from "axios";

// export const BASE_URL = "http://localhost:9094";
// export const BASE_URL2 = "http://localhost:9092";

// export const myAxios = axios.create({
//   baseURL: BASE_URL,
// });

// export const myAxiosnew = axios.create({
//   baseURL: BASE_URL2,
// });
