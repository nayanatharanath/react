import axios from "axios";

const COURSE_BASE_REST_API_URL = "http://localhost:8081/api/course";

class CourseService {
  getAllCourses() {
    return axios.get(COURSE_BASE_REST_API_URL);
  }

  createCourse(course) {
    return axios.post(COURSE_BASE_REST_API_URL, course);
  }
  getCourseByCode(courseCode) {
    return axios.get(COURSE_BASE_REST_API_URL + "/" + courseCode);
  }
  updateCourse(courseCode, course) {
    return axios
      .put(`/${courseCode}`, course)
      .then((response) => response.data);
  }
  deleteCourse(id) {
    return axios.delete(COURSE_BASE_REST_API_URL + "/" + id);
  }
}
export default new CourseService();
