import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
// import { toast } from "react-toastify";
import {
  Container,
  Card,
  Input,
  Button,
  FormGroup,
  Label,
  Col,
  CardTitle,
  CardText,
  CardImg,
  CardImgOverlay,
} from "reactstrap";
import Base from "../components/Base";
// import Footer from "../Footer";

const Home = () => {
  return (
    <Base>
      <h2>Home</h2>
    </Base>
  );
};
export default Home;
