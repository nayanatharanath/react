import React, { useEffect, useState, Component } from "react";
import { Routes, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { Navbar, Nav, Container } from "react-bootstrap";
import {
  FaDoorClosed,
  FaLockOpen,
  FaShoppingCart,
  FaSignOutAlt,
  FaShopify,
  FaUserCircle,
} from "react-icons/fa";
import logo from "./logo.svg";
import { ToastContainer } from "react-toastify";
import AuthService from "./services/auth.service";
import "./App.css";
// import Footer from "./Footer/Footer";
import EventBus from "./common/EventBus";
import Login from "./pages/login.component";
import Home from "./products/Home";
import Register from "./pages/register.component";
//import Profile from "./components/Profile";
import { useNavigate } from "react-router-dom";
import { AdminDashBoard } from "./pages/AdminDashBoard";
import ListMentorcomponent from "./components/ListMentorcomponent";
import HeaderComponent from "./components/HeaderComponent";
import Footercomponent from "./components/Footercomponent";
import AddMentorComponent from "./components/AddMentorComponent";
import UpdateMentorComponent from "./components/UpdateMentorComponent";
import ListCourseComponent from "./components/ListCourseComponent";
import AddCourseComponent from "./components/AddCourseComponent";

class App extends Component {
  constructor(props) {
    super(props);
    this.logOut = this.logOut.bind(this);

    this.state = {
      showMentorBoard: false,
      showAdminBoard: false,
      currentUser: undefined,
      navigate: useNavigate,
    };
  }
  componentDidMount() {
    const user = AuthService.getCurrentUser();

    if (user) {
      this.setState({
        currentUser: user,
        showMentorBoard: user.roles.includes("Mentor"),
        showAdminBoard: user.roles.includes("admin"),
      });
    }

    EventBus.on("logout", () => {
      this.logOut();
    });
  }

  componentWillUnmount() {
    EventBus.remove("logout");
  }

  logOut() {
    AuthService.logout();
    this.setState({
      showMentorBoard: false,
      showAdminBoard: false,
      currentUser: undefined,
    });
  }

  render() {
    //   const { currentUser, showMentorBoard, showAdminBoard } = this.state;

    return (
      <div className="container mt-3">
        <ToastContainer position="bottom-center" />

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Register />} />
          <Route path="/admin-dashboard" element={<AdminDashBoard />} />
          <Route exact path="/" element={<ListMentorcomponent />} />
          <Route path="/mentor" element={<ListMentorcomponent />} />
          <Route path="/add-mentor" element={<AddMentorComponent />} />
          <Route path="/edit-mentor/:id" element={<AddMentorComponent />} />

          <Route path="/course" element={<ListCourseComponent />} />
          <Route path="/add-course" element={<AddCourseComponent />} />
          <Route path="/edit-course/:id" element={<AddCourseComponent />} />
        </Routes>
      </div>
    );
  }
}

export default App;
