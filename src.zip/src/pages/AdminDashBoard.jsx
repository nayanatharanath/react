import React from 'react'

export const AdminDashBoard = () => {
  return (
    <div>AdminDashBoard</div>
  )
}
