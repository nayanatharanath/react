import React, { Component } from "react";
import Form from "react-validation/build/form";
import Input from "react-validation/build/input";
import CheckButton from "react-validation/build/button";
import { isEmail } from "validator";
import { Card } from "reactstrap";
import { toast } from "react-toastify";
import AuthService from "../services/auth.service";
import { textAlign } from "@mui/system";

const required = (value) => {
  if (!value) {
    return (
      <div className="alert alert-danger" role="alert">
        This field is required!
      </div>
    );
  }
};

const email = (value) => {
  if (!isEmail(value)) {
    return (
      <div className="alert alert-danger" role="alert">
        This is not a valid email.
      </div>
    );
  }
};

const vusername = (value) => {
  if (value.length < 3 || value.length > 20) {
    return (
      <div className="alert alert-danger" role="alert">
        The username must be between 3 and 20 characters.
      </div>
    );
  }
};

const vpassword = (value) => {
  if (value.length < 6 || value.length > 40) {
    return (
      <div className="alert alert-danger" role="alert">
        The password must be between 6 and 40 characters.
      </div>
    );
  }
};

export default class Register extends Component {
  constructor(props) {
    super(props);
    this.handleRegister = this.handleRegister.bind(this);
    this.onChangeUsername = this.onChangeUsername.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangePassword = this.onChangePassword.bind(this);

    this.state = {
      username: "",
      email: "",
      password: "",
      successful: false,
      message: "",
    };
  }

  onChangeUsername(e) {
    this.setState({
      username: e.target.value,
    });
  }

  onChangeEmail(e) {
    this.setState({
      email: e.target.value,
    });
  }

  onChangePassword(e) {
    this.setState({
      password: e.target.value,
    });
  }

  handleRegister(e) {
    e.preventDefault();

    this.setState({
      message: "",
      successful: false,
    });

    this.form.validateAll();

    if (this.checkBtn.context._errors.length === 0) {
      AuthService.register(
        this.state.username,
        this.state.email,
        this.state.password
      ).then(
        (response) => {
          toast.success("Registered Successfully");
          this.setState({
            message: response.data.message,
            successful: true,
          }, () => {
            setInterval(() => {
                window.location.href = '/login';
            }); 
          });
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();

          this.setState({
            successful: false,
            message: resMessage,
          });
        }
      );
    }
  }

  render() {
    return (
      <div className="mt-5">
        <Card
          style={{
            width: "20rem",
            background: "white"
          }}
        >
          <img
            src="https://i.pinimg.com/564x/c2/a1/c7/c2a1c77612cef282062d209ce6024f7f.jpg"
            alt="profile-img"
            style={{ position: "center"}}
            className="text-center"
            
          />
          <Form style={{marginLeft:"30px",  marginRight:"30px" }}
            onSubmit={this.handleRegister}
            ref={(c) => {
              this.form = c;
            }}
          >
            {!this.state.successful && (
              <div>
                <div className="form-group">
                  <label htmlFor="username" style={{
                  color: "black",
                  fontFamily: "Fuse",
                  fontSize: "20px",
                  marginLeft: "5rem",
                  marginTop:"1rem"
                }}>Username</label>
                  <Input
                    type="text"
                    className="form-control"
                    name="username"
                    value={this.state.username}
                    onChange={this.onChangeUsername}
                    validations={[required, vusername]}
                    style={{
                      color: "white",
                      border: "black",
                      background: "black",
                    }}
                    placeholder="Enter Username"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="email" style={{
                  color: "black",
                  fontFamily: "Fuse",
                  fontSize: "20px",
                  marginLeft: "6rem",
                  marginTop:"1rem"
                }}>Email</label>
                  <Input
                    type="text"
                    className="form-control"
                    name="email"
                    value={this.state.email}
                    onChange={this.onChangeEmail}
                    validations={[required, email]}
                    style={{
                      color: "white",
                      border: "black",
                      background: "black",
                    }}
                    placeholder="Enter EmailId"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="password" style={{
                  color: "black",
                  fontFamily: "Fuse",
                  fontSize: "20px",
                  marginLeft: "5rem",
                  marginTop:"1rem"
                }}>Password</label>
                  <Input
                    type="password"
                    className="form-control"
                    name="password"
                    value={this.state.password}
                    onChange={this.onChangePassword}
                    validations={[required, vpassword]}
                    style={{
                      color: "white",
                      border: "black",
                      background: "black",
                    }}
                    placeholder="Enter Password"
                  />
                </div>
                <br />
                <div className="form-group" style={{ marginBottom: "1rem", marginLeft:"5rem" }}>
                  <button className="btn btn-warning btn-block"><b>Sign Up</b></button>
                </div>
              </div>
            )}

            {this.state.message && (
              <div className="form-group">
                <div
                  className={
                    this.state.successful
                      ? "alert alert-success"
                      : "alert alert-danger"
                  }
                  role="alert"
                >
                  {this.state.message}
                </div>
              </div>
            )}
            <CheckButton
              style={{ display: "none" }}
              ref={(c) => {
                this.checkBtn = c;
              }}
            />
          </Form>
        </Card>
      </div>
    );
  }
}

/*Card
style={{
  background: "radial-gradient(circle, #0f2027, #203a43, #2c5364)",
  width: "40rem",
  marginTop: "10rem",
  marginRight: "10rem",
}}

Source, destination, date - label tag
style={{ color: "white" }}

search - button
style={{ marginRight: "15rem", opacity: "none" }}
color="warning"
*/
